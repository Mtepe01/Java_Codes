import java.io.*;
class Person
{
    public File kisi=new File("kisiler.txt");
    public FileWriter fw=new FileWriter(kisi.getPath(),true);
    private String Pozition;
    private String Name;
    private String Email;
    private double Salary;
    private Address address;
    private  GUN dogumTarihi;


    public Person(String Name, GUN dogumTarihi, String Pozition) throws IOException {
        this.Name = Name;
        this.Pozition=Pozition;
        this.dogumTarihi=dogumTarihi;

        if(kisi.length()==0)
        {
            fw.write("Ad Soyad"+ "Dogumtarihi(Gün Ay Yıl)"+ "Katagori \n");
        }

        fw.write(toString()+"\n");
        fw.close();
    }


    public String getName()
    {
        return Name;
    }
    public void setName(String Name)
    {
        this.Name = Name;
    }

    public String getEmail()
    {
        return Email;
    }
    public void setEmail(String Email)
    {
        this.Email = Email;
    }

    public double getSalary()
    {
        return Salary;
    }
    public void setSalary(double Salary)
    {
        this.Salary = Salary;
    }

    public Address getAddress()
    {
        return address;
    }
    public void setAddress(Address address)
    {
        this.address = address;
    }

    public String getPozition()
    {
        return Pozition;
    }

    public void setPozition(String pozition)
    {
        this.Pozition = pozition;
    }

    @Override
    public String toString() {
        return String.format("%s ; %d;%d;%d; %s",Name ,dogumTarihi.getDay(), dogumTarihi.getMonth(), dogumTarihi.getYear(),getPozition());
    }
}
