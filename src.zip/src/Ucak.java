import java.io.*;
class Ucak
{
    private  String tip;
    private  int kapasite;
    private  int uretimYili;
    private  Ucus ucuslar;
    private  Person kabinEkibi;
    public File ucak=new File("Ucak.txt");
    public FileWriter fw=new FileWriter("Ucak.txt",true);

    public Ucak(String tip ,int kapasite,int uretimYili,Ucus ucuslar,Person kabinEkibi) throws  IOException
    {
        this.kabinEkibi=kabinEkibi;
        this.tip=tip;
        this.kapasite=kapasite;
        this.uretimYili=uretimYili;
        this.ucuslar=ucuslar;
        if(ucak.length()==0)
        {
            fw.write("Tip"+" "+"Kapasite "+ " "+"uretim Yili\n");
        }
        String str =getTip()+" "+getKapasite()+" "+getUretimYili();
        fw.write(str+"\n");

        fw.close();
    }



    public void setTip(String tip)
    {
        this.tip=tip;
    }
    public String getTip()
    {
        return tip;
    }
    public void setKapasite(int kapasite)
    {
        this.kapasite=kapasite;
    }
    public int getKapasite()
    {
        return  kapasite;
    }
    public void  setUretimYili(int uretimYili)
    {
        this.uretimYili=uretimYili;
    }
    public int getUretimYili()
    {
        return  uretimYili;
    }
    public void setKabinEkibi(Person kabinEkibi)
    {
        this.kabinEkibi=kabinEkibi;
    }
    public Person getKabinEkibi()
    {
        return  kabinEkibi;
    }
    public void setUcuslar(Ucus ucuslar)
    {
        this.ucuslar=ucuslar;
    }
    public Ucus getUcuslar()
    {
        return  ucuslar;
    }

}
