class EmailBildirimi extends Bildirim
{
    private  String email;
    public  EmailBildirimi(int bildirimNo,GUN olusturulmaZamani,String icerik,String email)
    {
        super(bildirimNo,olusturulmaZamani,icerik);
        this.email=email;
    }

}