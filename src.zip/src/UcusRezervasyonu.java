import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

enum RezervasyonDurumu {
    tamamlandi,
    iptal,
    rezerve
}

class UcusRezervasyonu {
    private String rezervasyonNo;
    private Ucus ucus;
    private HashMap<Yolcu, UcusKoltugu> koltuk;
    private RezervasyonDurumu rezervasyonDurumu;

    public UcusRezervasyonu(String YolcuNo, String isimsoyisim, GUN baslangic, GUN bitis, GUN olusturulmaZamani, String rezervasyonNo, Ucus ucus, HashMap<Yolcu, UcusKoltugu> koltuk, RezervasyonDurumu rezervasyonDurumu) throws IOException {
        this.rezervasyonDurumu = rezervasyonDurumu;
        this.koltuk = koltuk;
        this.ucus = ucus;
        this.rezervasyonNo = rezervasyonNo;

        File rezervasyon = new File("Rezervasyonlar.txt");

        FileWriter fw = new FileWriter(rezervasyon.getPath(), true);

        if (rezervasyon.length() == 0) {
            fw.write("YolcuNumarası; Yolcuisim-soyisim; baslangic; bitis; olusturulmaZamani;rezervasyonNo;ucus;koltukNo;ucret;durum\n");
        }

        for (Yolcu yolcu : koltuk.keySet()) {
            UcusKoltugu yolcuKoltugu = (UcusKoltugu) koltuk.get(yolcu);
            String satir = String.format("%s;%s;%s;%s;%s;%s;%s;%s;%.2f;%s\n",
                    YolcuNo, isimsoyisim, baslangic, bitis, olusturulmaZamani,
                    rezervasyonNo, ucus.getUcusNo(), yolcuKoltugu.KoltukNo,
                    yolcuKoltugu.getUcret(), rezervasyonDurumu);
            fw.write(satir);
        }

        fw.close();
    }
}
