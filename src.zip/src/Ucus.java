import java.io.*;
enum Durum
{
    Zamanlandi,
    Tamamlandi
    ,Iptal;
}
class  Ucus
{
    public  File ucus=new File("Ucuslar.txt");
    public FileWriter fw=new FileWriter(ucus.getPath(),true);
    private  static int ucusNo=0;
    private  Airport kalkis;
    private  Airport varis;
    private  Ucak ucak;
    private GUN gun;
    private  Hour saat;
    private  int kapiNo;
    private Durum durum;
    public Ucus(int ucusNo, Airport kalkis, Airport varis, Ucak ucak, GUN gun, Hour saat, int kapiNo, Durum durum)throws  IOException
    {
        this.durum=durum;
        this.gun=gun;
        this.saat=saat;
        this.ucusNo=ucusNo;
        this.kapiNo=kapiNo;
        this.kalkis=kalkis;
        this.varis=varis;
        this.ucak=ucak;
        if(ucus.length()==0)
        {
            fw.write("cusNo"+" "+" Yıl;Ay;Gün;"+" " +"Saat(13:15)"+" "+ "Süre(dakika)" +" "+"KalkisKonum(Ulke;Sehir)"+" "+" KalkisHavalimaniAdi;"+" "+ "VarisKonum(Ulke;Sehir)" + " "+"VarisHavalimaniAdi"+" " +"Durum (1:Belirlendi,2:Tamamlandi,3:iptal)\n");
        }
        ucusNo++;
        fw.write(getUcusNo()+";"+getGun()+";"+getSaat()+";"+getKalkis()+";"+getVaris()+ ";"+getDurum()+"\n");

        fw.close();
    }



    public void setUcusNo(int ucusNo)
    {
        this.ucusNo=ucusNo;
    }
    public int getUcusNo()
    {
        return ucusNo;
    }
    public void setKalkis(Airport kalkis)
    {
        this.kalkis=kalkis;
    }
    public Airport getKalkis()
    {
        return kalkis;
    }
    public void setVaris( Airport varis)
    {
        this.varis=varis;
    }
    public Airport getVaris()
    {
        return  varis;
    }
    public void setUcak(Ucak ucak)
    {
        this.ucak=ucak;
    }
    public Ucak getUcak()
    {
        return ucak;
    }
    public void setGun(GUN gun)
    {
        this.gun=gun;
    }
    public GUN getGun()
    {
        return gun;
    }
    public void setSaat(Hour saat)
    {
        this.saat=saat;
    }
    public Hour getSaat()
    {
        return  saat;
    }
    public void setKapiNo(int kapiNo)
    {
        this.kapiNo=kapiNo;
    }
    public int getKapiNo()
    {
        return kapiNo;
    }
    public void durumGuncelle(Durum durum)
    {
        this.durum=durum;
    }
    public Durum getDurum()
    {
        return  durum;
    }
    public void setDurum(Durum durum)
    {
        this.durum=durum;
    }

}

