import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main
{
    public static void main(String[] args) throws IOException {

        Scanner scan = new Scanner(System.in);

        System.out.println("Please choose your position: \n1.Musteri\n2.Personal");
        int choose = scan.nextInt();

        switch (choose) {
            case 1: {
                int choose1;
                System.out.println("What you want to do? \n1.Check reservations\n2.Do new Reservation\n3.Set Rezervation State");
                choose1 = scan.nextInt();
                scan.nextLine();

                if (choose1 == 1) {
                    System.out.println(getUcusRezervasyonu());
                } else if (choose1==3)
                {
                    setUcusRezervasyonDurumu();
                } else {
                    addUcusRezervasyonu();
                }
                break;
            }
            case 2:
            {
                System.out.println("Please choose your pozition \n 1.Yönetici\n2.Calisan\n3.KabinUyesi\n4.Pilot");
                int choose2;
                choose2=scan.nextInt();
                scan.nextLine();
                switch (choose2)
                {
                    case 1:
                        getUcuslar();
                        addNewUcus();
                        break;
                    case 2:
                        getUcuslar();
                        break;
                    case 3:
                        getUcuslar();
                        break;
                    case 4:
                        getUcuslar();
                        break;
                }

                break;
            }
            default:
                System.out.println("Invalid choose");
        }

      // System.out.println(getUcusRezervasyonu());

    }

    public static String getUcusRezervasyonu() throws IOException {
        Scanner scan = new Scanner(System.in);
        String name;
        System.out.println("Please enter the name");
        name = scan.nextLine();

        Scanner scan1 = new Scanner(new File("Rezervasyonlar.txt"));
        while (scan1.hasNextLine()) {
            String line = scan1.nextLine();
            String[] str = line.split(";");

            if (str.length > 1 && str[1].equals(name)) {
                return line;
            }
        }

        return "There is no reservation";
    }
    public static RezervasyonDurumu setUcusRezervasyonDurumu() {
        System.out.println("Please choose the Rezervation state \n1.tamamlandi\n2.iptal\n3.rezerve");
        int choose;
        Scanner scan = new Scanner(System.in);
        choose = scan.nextInt();
        scan.nextLine();
        RezervasyonDurumu durum;

        switch (choose) {
            case 1:
                durum = RezervasyonDurumu.tamamlandi;
                break;
            case 2:
                durum = RezervasyonDurumu.iptal;
                break;
            case 3:
                durum = RezervasyonDurumu.rezerve;
                break;
            default:

                System.out.println("Invalid selection. Defaulting to 'rezerve'.");
                durum = RezervasyonDurumu.rezerve;
                break;
        }

        return durum;
    }
        public static void addUcusRezervasyonu() throws IOException {
            Scanner scan = new Scanner(System.in);
            Random rand = new Random();

            String yolcuNo = String.valueOf(rand.nextInt(100));
            System.out.println("Please enter the passenger's full name:");
            String isimSoyisim = scan.nextLine();

            System.out.println("Please enter the reservation start date (day month year):");
            int[] start = getInputDate(scan);
            GUN baslangic = new GUN(start[2], start[1], start[0]);

            System.out.println("Please enter the reservation deadline date (day month year):");
            int[] bitis = getInputDate(scan);
            GUN bitisGun = new GUN(bitis[2], bitis[1], bitis[0]);

            LocalDate today = LocalDate.now();
            GUN olusturulmaZamani = new GUN(today.getYear(), today.getMonthValue(), today.getDayOfMonth());

            String rezervasyonNoStr = String.valueOf(rand.nextInt(100));

            System.out.println("Please select your flight:");
            getUcuslar();
            System.out.println("Please enter the flight number:");
            int ucusNo = scan.nextInt();
            scan.nextLine();

            System.out.println("Please enter the departure airport name:");
            String kalkisHavalimani = scan.nextLine();
            System.out.println("Please enter the departure airport location (City):");
            String locationKCity = scan.nextLine();
            System.out.println("Please enter the departure airport location (Country):");
            String locationKCountry = scan.nextLine();
            Location locationK = new Location(locationKCountry, locationKCity);
            Airport kalkis = new Airport(kalkisHavalimani, locationK);

            System.out.println("Please enter the arrival airport name:");
            String varisHavalimani = scan.nextLine();
            System.out.println("Please enter the arrival airport location (Country):");
            String locationVCountry = scan.nextLine();
            System.out.println("Please enter the arrival airport location (City):");
            String locationVCity = scan.nextLine();
            Location locationV = new Location(locationVCountry, locationVCity);
            Airport varis = new Airport(varisHavalimani, locationV);

            System.out.println("Please enter the flight date (day month year):");
            int[] gun = getInputDate(scan);
            GUN gunUcus = new GUN(gun[2], gun[1], gun[0]);
            System.out.println("Please enter the flight time (hour minute second):");
            int[] saat = getInputTime(scan);
            Hour flightHour = new Hour(saat[0], saat[1], saat[2]);

            int kapiNo = rand.nextInt(10);
            Durum status = Durum.Zamanlandi;

            Ucak ucak = rastgeleUcakSec();
            Ucus ucus = new Ucus(ucusNo, kalkis, varis, ucak, gunUcus, flightHour, kapiNo, status);

            System.out.println("Please enter the passenger's birthdate (day month year):");
            int[] dogTar = getInputDate(scan);
            GUN dogumTarihi = new GUN(dogTar[2], dogTar[1], dogTar[0]);

            System.out.println("Please enter the passport number:");
            String pasaportNo = scan.nextLine();

            HashMap<Yolcu, UcusKoltugu> koltukMap = new HashMap<>();
            System.out.println("Please enter the seat number:");
            String koltukNo = scan.nextLine();
            System.out.println("Please choose the seat class:\n1. Business(1000TL)\n2. Economy(500TL)\n3. Premium(750TL)");
            KoltukSinifi koltukSinifi = getKoltukSinifi(scan);

            System.out.println("Please choose the seat type:\n1. Standard\n2. Child(-200)\n3. Wide(+200)");
            KoltuKTuru koltuKTuru = getKoltuKTuru(scan);
            float KoltukUcreti= 0.0f;
            switch (koltukSinifi)
            {
                case Business :
                    switch (koltuKTuru)
                    {
                        case standart :
                            KoltukUcreti=1000;
                            break;
                        case cocuk:
                            KoltukUcreti=800;
                            break;
                        case genis:
                            KoltukUcreti=1200;
                            break;
                        default:
                            System.out.println("Invalid input");
                    }
                        break;
                case Economy:
                {
                    switch (koltuKTuru)
                    {
                        case standart:
                            KoltukUcreti = 500;
                            break;
                        case cocuk:
                            KoltukUcreti = 300;
                            break;
                        case genis:
                            KoltukUcreti = 700;
                            break;
                        default:
                            System.out.println("Invalid input");
                    }
                    break;
                }
                case Premium: {
                    switch (koltuKTuru) {
                        case standart:
                            KoltukUcreti = 750;
                            break;
                        case cocuk:
                            KoltukUcreti = 550;
                            break;
                        case genis:
                            KoltukUcreti = 950;
                            break;
                        default:
                            System.out.println("Invalid input");
                    }
                    break;
                }
                default:
                    System.out.println("Invalid input");
                    break;
            }


            String rezervastyonNo = String.valueOf(rand.nextInt(0,1000));
            UcusKoltugu koltuk = new UcusKoltugu(koltukNo,koltuKTuru,koltukSinifi,KoltukUcreti,rezervastyonNo);
            Yolcu yolcu = new Yolcu(isimSoyisim, pasaportNo, dogumTarihi);
            koltukMap.put(yolcu, koltuk);

            UcusRezervasyonu ucusRezervasyonu = new UcusRezervasyonu(yolcuNo, isimSoyisim, baslangic, bitisGun, olusturulmaZamani, rezervasyonNoStr, ucus, koltukMap, setUcusRezervasyonDurumu());

            System.out.println("Flight reservation created successfully!");
        }


        private static int[] getInputDate(Scanner scan) {
            int[] date = new int[3];
            for (int i = 0; i < 3; i++) {
                date[i] = scan.nextInt();
            }
            scan.nextLine();
            return date;
        }


        private static int[] getInputTime(Scanner scan) {
            int[] time = new int[3];
            for (int i = 0; i < 3; i++) {
                time[i] = scan.nextInt();
            }
            scan.nextLine();
            return time;
        }


        private static KoltukSinifi getKoltukSinifi(Scanner scan) {
            int choice = scan.nextInt();
            scan.nextLine();
            switch (choice) {
                case 1: return KoltukSinifi.Business;
                case 2: return KoltukSinifi.Economy;
                case 3: return KoltukSinifi.Premium;
                default:
                    System.out.println("Invalid selection! Defaulting to Economy.");
                    return KoltukSinifi.Economy;
            }
        }


        private static KoltuKTuru getKoltuKTuru(Scanner scan) {
            int choice = scan.nextInt();
            scan.nextLine();
            switch (choice) {
                case 1: return KoltuKTuru.standart;
                case 2: return KoltuKTuru.cocuk;
                case 3: return KoltuKTuru.genis;
                default:
                    System.out.println("Invalid selection! Defaulting to Standard.");
                    return KoltuKTuru.standart;
            }
        }


    public static void getUcuslar() throws IOException {
        Scanner scan = new Scanner(new File("Ucuslar.txt"));
        int ucusNo = 1;

        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] str = line.split(";");

            if (str.length > 0) {
                String durum = str[str.length - 1].trim();
                if (durum.equals("1")) {
                    System.out.println(ucusNo + ": " + line);
                    ucusNo++;
                }
            }
        }
    }

    public static Ucak rastgeleUcakSec() throws IOException {
        ArrayList<String> lines = new ArrayList<>();
        Scanner scan = new Scanner(new File("Ucaklar.txt"));


        while (scan.hasNextLine()) {
            String line = scan.nextLine().trim();
            if (!line.isEmpty()) {
                lines.add(line);
            }
        }

        if (lines.isEmpty()) {
            throw new IOException("No valid lines found in the file.");
        }

        Random random = new Random();
        int index = random.nextInt(1,lines.size()-1);
        String selectedLine = lines.get(index);


        String[] parts = selectedLine.split(";");
        if (parts.length != 3) {
            throw new IOException("Invalid line format: " + selectedLine);
        }

        String ucakTipi = parts[0].trim();
        int kapasite = Integer.parseInt(parts[1].trim());
        int uretimYili = Integer.parseInt(parts[2].trim());

        return new Ucak(ucakTipi, kapasite, uretimYili, null, null);
    }


    /* public static Ucus getUcusByUcusNo(int ucusNo) throws IOException {
        Scanner scan = new Scanner(new File("Ucuslar.txt"));
        int currentUcusNo = 1;

        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] str = line.split(";");

            if (str.length > 0 && currentUcusNo == ucusNo) {

                String ucusKodu = str[0];
                String kalkis = str[1];  // Kalkış noktası
                String varis = str[2];   // Varış noktası
                String saat = str[3];    // Saat
                String durum = str[4];   // Durum (1: Belirlendi, 2: Tamamlandi, 3: İptal)

                Ucus selectedUcus = new Ucus(ucusNo, new Airport(kalkis), new Airport(varis), new Ucak(), new GUN(2022, 11, 12), new Hour(14, 30), 3, Durum.Tamamlandi);
                return selectedUcus;
            }
            currentUcusNo++;
        }

        return null; */
    public static void addNewUcus() throws IOException
    {
        Scanner scan=new Scanner(System.in);

        int ucusNo;
        Airport kalkis;
        Airport varis;
        Ucak ucak;

        int kapiNo;

        System.out.println("Please enter the UcusNo");
        ucusNo=scan.nextInt();
        scan.nextLine();
        String kalkisAirportName;
        System.out.println("Please enter the kalkis airport name");
        kalkisAirportName=scan.nextLine();
        String YoneticiName;
        System.out.println("Please enter the Manager Name of the kalkıs airport");
        YoneticiName=scan.nextLine();

        GUN yoneticiDogTar;

        System.out.println("Please enter the Yönetici DogTar day to year");
        int[] dogTar=new int[3];
        for(int i=0;i<3;i++)
        {
            dogTar[i]=scan.nextInt();
            scan.nextLine();
        }
        yoneticiDogTar=new GUN(dogTar[2],dogTar[1],dogTar[0]);

        Yonetici yonetici=new Yonetici(YoneticiName,yoneticiDogTar,"Yönetici");

        Location kalkisLocation;

        String KalkisCity;
        String KalkisCountry;
        System.out.println("Please enter the Kalkis city");
        KalkisCity=scan.nextLine();
        System.out.println("Please enter the Kalkis Country");
        KalkisCountry=scan.nextLine();

        kalkisLocation=new Location(KalkisCountry,KalkisCity);

        kalkis=new Airport(kalkisAirportName,yonetici,kalkisLocation);

        String VarisAirportName;
        System.out.println("Please enter the varis Airport name");
        VarisAirportName=scan.nextLine();

        Yonetici varisYonetici;
        String  varisYoneticiName;
        System.out.println("Please enter the varis yönetici Name");
        varisYoneticiName=scan.nextLine();

        GUN varisYoneticiDogTar;
        System.out.println("Please enter the varis yonetici dog tar day to year");
        int[] varisYoneticiDogtar=new int[3];
        for (int i=0; i<3;i++)
        {
         varisYoneticiDogtar[i]=scan.nextInt();
         scan.nextLine();
        }
        varisYoneticiDogTar=new GUN(varisYoneticiDogtar[2],varisYoneticiDogtar[1],varisYoneticiDogtar[0]);
        varisYonetici=new Yonetici(varisYoneticiName,varisYoneticiDogTar,"Yönetici");

        Location varisLocation;

        System.out.println("Please enter the Varis location information City and country");
        String varisAirportCity,varisAirportCountry;
        varisAirportCity=scan.nextLine();
        varisAirportCountry=scan.nextLine();
        varisLocation=new Location(varisAirportCountry,varisAirportCity);
        varis=new Airport(VarisAirportName,varisYonetici,varisLocation);
        int kapasite;
        System.out.println("Please enter the kapasite of the airplane");
        kapasite=scan.nextInt();
        scan.nextLine();
        String Ucaktipi;
        System.out.println("Please enter the Ucak Type");
        Ucaktipi=scan.nextLine();
        String  KabinUyesiName;
        System.out.println("Please enter the Kabin uyesi name");
        KabinUyesiName=scan.nextLine();
        GUN kabinUyesiDogTar;
        System.out.println("Please enter the Kabin Uyesi dog tar day to year");
        int kabinuyesiDog[] =new int[3];
        for(int i=0;i<3;i++)
        {
            kabinuyesiDog[i]=scan.nextInt();
            scan.nextLine();
        }
        kabinUyesiDogTar=new GUN(kabinuyesiDog[2],kabinuyesiDog[1],kabinuyesiDog[0]);

        String Pozition;
        System.out.println("Please enter the Kabin uyesi pozition ");
        Pozition=scan.nextLine();

        KABINUYESI kabinuyesi=new KABINUYESI(KabinUyesiName,kabinUyesiDogTar,Pozition,20,20,20000);
        int uretimYili;
        System.out.println("Please enter the üretim yili");
        uretimYili=scan.nextInt();
        scan.nextLine();
        Ucus ucus1=null;
        Ucak ucak1 =new Ucak(Ucaktipi,kapasite,uretimYili,ucus1,kabinuyesi);

        GUN ucusGunu;
        int[] ucsGUN=new int[3];
        System.out.println("Please enter the ucusDAY  day to year ");
        for(int i=0;i<3; i++)
        {
            ucsGUN[i]=scan.nextInt();
            scan.nextLine();
        }
        ucusGunu=new GUN(ucsGUN[2],ucsGUN[1],ucsGUN[2]);

        Hour ucusSaati;
        System.out.println("Please enter the ucus saati hour to second");
        int[] ucsSaat=new int[3];

        for (int i=0;i<3;i++)
        {
            ucsSaat[i]=scan.nextInt();
            scan.nextLine();
        }
        ucusSaati=new Hour(ucsSaat[0],ucsSaat[1],ucsSaat[2]);
        System.out.println("Please enter the airplane door no ");
        kapiNo=scan.nextInt();
        scan.nextLine();
        System.out.println("Please choose the State of the ucus 1.Zamanlandi,\n2.Tamamlandi\n3.Iptal;");


        Ucus ucus=new Ucus(ucusNo,kalkis,varis,ucak1,ucusGunu,ucusSaati,kapiNo,getDurum());
    }
    public static Durum getDurum() {
        Scanner scan = new Scanner(System.in);
        Durum durum;
        int durumChoose;
        durumChoose = scan.nextInt();
        scan.nextLine();
        if (durumChoose == 1) {
            return Durum.Zamanlandi;
        } else if (durumChoose == 2) {
            return Durum.Tamamlandi;
        } else

            return Durum.Iptal;
    }
}

