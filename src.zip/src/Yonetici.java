import java.io.*;
class Yonetici extends Person
{
    private String Departman;
    public Yonetici(String Name, GUN dogumTarihi, String Pozition) throws IOException
    {

        super(Name,dogumTarihi,Pozition);
    }
    public void setDepartman(String Departman)
    {
        this.Departman=Departman;
    }
    public String getDepartman()
    {
        return Departman;
    }
    /*public boolean UcakEkle()
    {
        return
    }*/
    public String toString()
    {

        return String.format("%s Departman: %s ",super.toString(),getDepartman());
    }
}
