import java.io.*;
class Musteri extends  Person
{
    private  String yolcuNumarasi;
    public Musteri(String Name, GUN dogumTarihi,String pozisyon,String yolcuNumarasi) throws IOException {
        super(Name,dogumTarihi,pozisyon);
        this.yolcuNumarasi=yolcuNumarasi;
    }

    public void setYolcuNumarasi(String yolcuNumarasi)
    {
        this.yolcuNumarasi=yolcuNumarasi;
    }
    public  String getYolcuNumarasi()
    {
        return  yolcuNumarasi;
    }
    public String toString()
    {
        return String.format("%s ",super.toString(),"Yolcu Numarasi",getYolcuNumarasi());
    }
}

