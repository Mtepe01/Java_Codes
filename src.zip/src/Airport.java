import java.io.*;
class Airport
{
    private String name;
    private Location location;

    private Yonetici yonetici;
    public File Havalimani = new File("Havalimanlari.txt");
    public FileWriter fw=new FileWriter(Havalimani.getPath());
    // Constructor
    public Airport(String name, Yonetici yonetici, Location location) throws IOException {
        this.name = name;
        this.yonetici = yonetici;
        this.location = location;
        if(Havalimani.length()==0)
        {
            fw.write("havalimaniAdi"+" " +"YoneticiAdSoyad DTarih(Yil);Ay;Gün;Maas Kategori (Yonetici)"+" "+"Konum (Ülke;Şehir)\n");
        }
        fw.write(getName()+" "+getYonetici()+" "+getLocation()+"\n");
        fw.close();
    }
    public Airport(String name,Location location) throws IOException {
        this.name=name;
        this.location=location;
    }


    @Override
    public String toString() {
        return String.format("name=%s  yonetici=%s location=%s ",
                name, yonetici, location);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Yonetici getYonetici() {
        return yonetici;
    }

    public void setYonetici(Yonetici yonetici) {
        this.yonetici = yonetici;
    }
}
