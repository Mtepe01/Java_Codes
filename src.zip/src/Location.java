class Location
{
    private String Country;
    private String City;
    public Location(String Country,String City)
    {
        this.City=City;
        this.Country=Country;
    }
    public void setCountry(String Country)
    {
        this.Country=Country;
    }
    public void setCity(String City)
    {
        this.City=City;
    }
    public String getCountry()
    {
        return Country;
    }
    public String getCity()
    {
        return  City;
    }
}
