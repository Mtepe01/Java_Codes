
class IslemiKontrolEt extends Odeme
{
    private  String bankaAdi;
    private String NumarayiKontrolEt;
    public IslemiKontrolEt(int odemeID,double miktar,OdemeDurumu odemeDurumu,String bankaAdi,String NumarayiKontrolEt)
    {
        super(odemeID,miktar,odemeDurumu);
        this.bankaAdi=bankaAdi;
        this.NumarayiKontrolEt=NumarayiKontrolEt;
    }
}