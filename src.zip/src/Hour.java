class Hour
{
    private  int saat;
    private  int dakika;
    private  int saniye;
    public Hour(int saat,int dakika,int saniye)
    {
        this.saat=saat;
        this.dakika=dakika;
        this.saniye=saniye;
    }
    public void setSaat(int saat)
    {
        this.saat=saat;
    }
    public int getSaat()
    {
        return  saat;
    }
    public void setDakika(int dakika)
    {
        this.dakika=dakika;
    }
    public int getDakika()
    {
        return  dakika;
    }
    public void setSaniye(int saniye)
    {
        this.saniye=saniye;
    }
    public int getSaniye()
    {
        return  saniye;
    }
}