import java.io.*;
class KABINUYESI extends Person
{
    private Ucus ucuslar;
    private float toplamSaat;
    private int toplamUcus;
    private float temelMaas;

    public KABINUYESI(String Name, GUN dogumTarihi, String Pozition,int toplamUcus,int toplamSaat,float temelMaas) throws IOException
    {
        super(Name,dogumTarihi,Pozition);
        this.temelMaas=temelMaas;
        this.toplamSaat=toplamSaat;
        this.toplamUcus=toplamUcus;
    }

    public float getToplamSaat()
    {
        return toplamSaat; }
    public void setToplamSaat(float toplamSaat) { this.toplamSaat = toplamSaat; }

    public int getToplamUcus() { return toplamUcus; }
    public void setToplamUcus(int toplamUcus) { this.toplamUcus = toplamUcus; }

    public float getTemelMaas() { return temelMaas; }
    public void setTemelMaas(float temelMaas) { this.temelMaas = temelMaas; }

    public Ucus getUcuslar()
    {
        return ucuslar;
    }
    public void setUcuslar(Ucus ucuslar)
    {
        this.ucuslar=ucuslar;
    }
    public String toString()
    {
        return String.format("%s, Toplam Ucus Suresi: %.2f, Toplam Ucus: %d, Temel Maas: %.2f", super.toString(), getToplamSaat(), getToplamUcus(), getTemelMaas());
    }

}
