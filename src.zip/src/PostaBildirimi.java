class PostaBildirimi extends Bildirim
{
    private String Adres;
    public PostaBildirimi(int bildirimNo,GUN olusturulmaZamani,String icerik,String Adres)
    {
        super( bildirimNo,olusturulmaZamani, icerik);
        this.Adres=Adres;
    }
}

