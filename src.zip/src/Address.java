class Address
{
    private String Sehir;
    private String Sokak;
    private String Ulke;
    private String PostCode;
    public Address(String Sehir,String Sokak,String Ulke,String PostCode)
    {
        this.Sehir=Sehir;
        this.Sokak=Sokak;
        this.Ulke=Ulke;
        this.PostCode=PostCode;
    }
    public void setPostCode(String PostCode)
    {
        this.PostCode=PostCode;
    }
    public String getPostCode()
    {
        return PostCode;
    }

    public void setSokak(String Sokak) {
        this.Sokak = Sokak;
    }
    public String getSokak()
    {
        return  Sokak;
    }
    public void setSehir(String Sehir)
    {
        this.Sehir=Sehir;
    }
    public String getSehir()
    {
        return Sehir;
    }

    public String getUlke() {
        return Ulke;
    }

    public void setUlke(String Ulke) {
        this.Ulke = Ulke;
    }
}
