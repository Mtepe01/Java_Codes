class Bildirim
{
    private int bildirimNo;
    private GUN olusturulmaZamani;
    private String icerik;
    public Bildirim(int bildirimNo,GUN olusturulmaZamani,String icerik)
    {
        this.bildirimNo=bildirimNo;
        this.icerik=icerik;
        this.olusturulmaZamani=olusturulmaZamani;
    }
    public boolean Gonder()
    {
        return true;
    }

}
