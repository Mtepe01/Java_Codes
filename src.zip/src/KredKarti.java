
class KrediKarti extends  Odeme
{
    private String KartUzerindekiIsim;
    public KrediKarti(int odemeID,double miktar,OdemeDurumu odemeDurumu,String KartUzerindekiIsim)
    {
        super(odemeID,miktar,odemeDurumu);
        this.KartUzerindekiIsim=KartUzerindekiIsim;
    }
}