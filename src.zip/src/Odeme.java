enum OdemeDurumu
{
    odendi,
    bekleniyor,
    odenmedi
};
class Odeme
{
    private int odemeID;
    private double miktar;
    private OdemeDurumu odemeDurumu;
    public Odeme(int odemeID,double miktar,OdemeDurumu odemeDurumu)
    {
        this.miktar=miktar;
        this.odemeDurumu=odemeDurumu;
        this.odemeID=odemeID;
    }
    public void setOdemeID(int odemeID)
    {
        this.odemeID=odemeID;
    }
    public int getOdemeID()
    {
        return odemeID;
    }
    public void setMiktar(double miktar)
    {
        this.miktar=miktar;
    }
    public double getMiktar()
    {
        return miktar;
    }
    public void setOdemeDurumu(OdemeDurumu odemeDurumu)
    {
        this.odemeDurumu=odemeDurumu;
    }
    public OdemeDurumu getOdemeDurumu()
    {
        return odemeDurumu;
    }
    public boolean IslemYap(OdemeDurumu odemeDurumu)
    {
        return odemeDurumu == OdemeDurumu.odendi;
    }

}
