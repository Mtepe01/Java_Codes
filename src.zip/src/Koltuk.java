enum  KoltuKTuru
{
    standart,
    genis,
    cocuk
};
enum KoltukSinifi
{
    Business,
    Economy,
    Premium
};
class Koltuk
{
    String KoltukNo;
    KoltuKTuru koltukTipi;
    KoltukSinifi sinif;
    public Koltuk(String KoltukNo, KoltuKTuru koltukTipi, KoltukSinifi sinif)
    {
        this.KoltukNo=KoltukNo;
        this.sinif=sinif;
        this.koltukTipi=koltukTipi;
    }

    public KoltuKTuru getKoltukTuru() {
        return koltukTipi;
    }
}