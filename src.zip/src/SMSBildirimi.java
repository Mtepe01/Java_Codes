
class SMSBildirimi extends Bildirim
{
    private  String telNo;
    public SMSBildirimi(int bildirimNo,GUN olusturulmaZamani,String icerik,String telNo)
    {
        super( bildirimNo, olusturulmaZamani,icerik);
        this.telNo=telNo;
    }
}
