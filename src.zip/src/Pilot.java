import java.io.*;
class Pilot  extends Person
{
    private Ucus ucuslar;
    private String ucakTipi;
    private float toplamUcus;
    private int toplamSaat;
    private float temelMaas;
    public Pilot (String Name, GUN dogumTarihi, String Pozition, String ucakTipi,int toplamUcus,int toplamSaat,float temelMaas) throws IOException
    {
        super(Name,dogumTarihi,Pozition);
        this.ucakTipi=ucakTipi;
        this.toplamSaat=toplamSaat;
        this.toplamUcus=toplamUcus;
        this.temelMaas=temelMaas;
    }
    public void setUcuslar(Ucus ucuslar)
    {
        this.ucuslar=ucuslar;
    }
    public Ucus getUcuslar()
    {
        return ucuslar;
    }
    public void setUcakTipi(String ucakTipi)
    {
        this.ucakTipi=ucakTipi;
    }
    public String getUcakTipi()
    {
        return ucakTipi;
    }

    public float getTemelMaas()
    {
        return temelMaas;
    }
    public void setTemelMaas(float temelMaas)
    {
        this.temelMaas=temelMaas;
    }
    public  String toString()
    {
        return String.format("Pilot Bilgileri: %s, Uçak Tipi: %s, Toplam Uçuş: %.2f, Toplam Saat: %d, Temel Maaş: %.2f", super.toString(), ucakTipi, toplamUcus, toplamSaat, temelMaas);
    }
}

