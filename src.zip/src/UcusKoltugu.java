class UcusKoltugu extends Koltuk {
    private float ucret;
    String rezervasyonNo;

    public UcusKoltugu(String koltukNo, KoltuKTuru koltukTipi, KoltukSinifi sinif, float ucret, String rezervasyonNo) {
        super(koltukNo, koltukTipi, sinif);
        this.rezervasyonNo = rezervasyonNo;
        this.ucret = ucret;
    }

    public float getUcret() {
        return ucret;
    }
}
