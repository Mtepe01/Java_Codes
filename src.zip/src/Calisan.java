import java.io.*;
class Calisan extends Person
{
    private String tarife;
    public Calisan (String Name, GUN dogumTarihi,String pozisyon,String tarife) throws IOException
    {
        super(Name,dogumTarihi,pozisyon);
        this.tarife=tarife;
    }
    public String getTarife()
    {
        return tarife;
    }
    public void setTarife(String tarife)
    {
        this.tarife=tarife;
    }
    public String toString()
    {
        return String.format(" %s Tarife: %s",super.toString(),getTarife());
    }
}