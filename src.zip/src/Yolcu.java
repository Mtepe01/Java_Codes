class Yolcu
{
    private String isim_soyisim;
    private String pasaportNO;
    private  GUN dogumTarihi;

    public Yolcu(String isim_soyisim,String pasaportNO,GUN dogumTarihi)
    {
        this.dogumTarihi=dogumTarihi;
        this.isim_soyisim=isim_soyisim;
        this.pasaportNO=pasaportNO;
    }
    public String  getPasaportNO()
    {
        return pasaportNO;
    }
    public String getPasaportNo()
    {
        return pasaportNO;
    }
    public GUN getDogumTarihi()
    {
        return dogumTarihi;
    }
}
