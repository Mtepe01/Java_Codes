import java.io.*;
import java.util.ArrayList;
class AirlineCompany {
    private String name;
    private String code;
    private ArrayList<Airport> airports;
    private  ArrayList<Ucus> ucuslar;

    public File airline=new File("HavayoluSirketi.txt");
    public FileWriter fw=new FileWriter(airline.getPath());
    //Dosyaya yazmamamıza rağmen parametre olarak alıyoruz UML diagramından dolayı
    public AirlineCompany(String name, String code, Airport airports, Ucus ucuslar) throws IOException {
        this.name = name;
        this.code = code;
        this.airports = new ArrayList<>();
        this.ucuslar = new ArrayList<>();
        fw.write(airports.getName()+"\n");
        fw.close();
    }

    public void creatAirport(Airport airport)
    {
        airports.add(airport);
    }


    public void addUcuslar(Ucus Ucuslar)
    {
        ucuslar.add(Ucuslar);
    }


    public void deleteUcuslar(Ucus ucus)
    {
        ucuslar.remove(ucus);
    }

    public void deleteAirport(String airport) {
        airports.remove(airport);
    }


    public void updateUcuslar(Ucus oldUcus, Ucus newUcus) {
        int index = ucuslar.indexOf(oldUcus);
        if (index != -1) {
            ucuslar.set(index, newUcus);
        }
    }
    public void updateAirport(String oldAirport, String newAirport)
    {

    }

    public ArrayList<Airport> getAirports()
    {
        return airports;
    }
    public ArrayList<Ucus> getUcuslar()
    {
        return ucuslar;
    }
    @Override
    public String toString() {
        return String.format("name='%s', code='%s', airports=%s, flights=%s ",name, code, airports, ucuslar);
    }
}
