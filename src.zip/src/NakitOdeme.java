class NakitOdeme extends Odeme
{
    private double NakitTeklifi;
    public NakitOdeme(int odemeID,double miktar,OdemeDurumu odemeDurumu,double NakitTeklif)
    {
        super(odemeID,miktar,odemeDurumu);
        this.NakitTeklifi=NakitTeklif;
    }
}
